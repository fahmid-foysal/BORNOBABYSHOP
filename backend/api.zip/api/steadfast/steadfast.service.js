const { pool, transaction } = require("../../config/database");
const {
  z,
  id,
  amount,
  HttpError,
  one,
  insert,
  pagination,
  pageResult,
} = require("../../lib/http");
const { round } = require("../../lib/sale-math");
async function request(endpoint, body) {
  if (!process.env.STEADFAST_API_KEY || !process.env.STEADFAST_SECRET_KEY)
    throw new HttpError(
      503,
      "Set the Steadfast API key and secret in backend/.env",
    );
  const response = await fetch(
    `${process.env.STEADFAST_BASE_URL || "https://portal.packzy.com/api/v1"}${endpoint}`,
    {
      method: body ? "POST" : "GET",
      headers: {
        "Api-Key": process.env.STEADFAST_API_KEY,
        "Secret-Key": process.env.STEADFAST_SECRET_KEY,
        "Content-Type": "application/json",
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(30000),
    },
  );
  if (!response.ok)
    throw new HttpError(502, `Steadfast returned HTTP ${response.status}`);
  return response.json();
}
exports.send = async (keys, bulk = false) => {
  if (!process.env.STEADFAST_API_KEY || !process.env.STEADFAST_SECRET_KEY)
    throw new HttpError(
      503,
      "Steadfast credentials are not configured; orders were saved locally",
    );
  const data = await transaction(async (db) => {
    const rows = [];
    for (const key of keys) {
      const s = await one(
        db,
        "SELECT s.*,c.cus_name,c.cus_phone,c.cus_address FROM online_sales s JOIN customers c ON c.id=s.customer_id WHERE s.id=? FOR UPDATE",
        [id.parse(key)],
      );
      if (s.sent_to_steadfast)
        throw new HttpError(409, `ORD-${key} has already been sent`);
      if (s.status === "returned")
        throw new HttpError(409, "Returned orders cannot be dispatched");
      if (s.steadfast_submitted_at)
        throw new HttpError(
          409,
          `ORD-${key} has an unresolved dispatch attempt. Check its invoice in the courier portal before reconciling.`,
        );
      const [[v]] = await db.query(
        "SELECT (SELECT COALESCE(SUM(quantity*rate),0) FROM sale_lines WHERE channel='online' AND sale_id=?) subtotal,(SELECT COALESCE(SUM(amount),0) FROM online_sale_payments WHERE online_sale_id=?) paid",
        [key, key],
      );
      const cod = round(
        Math.max(0, v.subtotal - s.final_discount + s.delivery_charge - v.paid),
      );
      await db.query(
        "UPDATE online_sales SET steadfast_submitted_at=NOW(),steadfast_cod_amount=?,steadfast_last_error=NULL WHERE id=?",
        [cod, key],
      );
      const [firstItems] = await db.query(
        "SELECT item_name FROM sale_lines WHERE channel='online' AND sale_id=? ORDER BY line_id LIMIT 1",
        [key],
      );
      const firstItemName = String(firstItems[0]?.item_name || "ORDER")
        .trim()
        .replace(/\s+/g, "_")
        .slice(0, 120);
      rows.push({
        invoice: `${firstItemName}_ORD-${key}`,
        recipient_name: s.cus_name,
        recipient_phone: s.cus_phone,
        recipient_address: s.cus_address,
        cod_amount: cod,
        total_lot: s.steadfast_lot || 1,
        note: s.steadfast_note || s.notes || "",
      });
    }
    return rows;
  });
  let response;
  try {
    response = await request(
      bulk ? "/create_order/bulk-order" : "/create_order",
      bulk ? { data } : data[0],
    );
  } catch (e) {
    await transaction(async (db) => {
      for (const key of keys)
        await db.query(
          "UPDATE online_sales SET steadfast_last_error=? WHERE id=?",
          [
            `Unconfirmed dispatch: ${e.message}. Reconcile this invoice in the Steadfast portal before retrying.`,
            key,
          ],
        );
    });
    return { error: e.message, uncertain: true };
  }
  const results = bulk
    ? Array.isArray(response.data)
      ? response.data
      : []
    : [
        response.consignment
          ? {
              ...response.consignment,
              invoice: data[0].invoice,
              status: Number(response.status) === 200 ? "success" : "failed",
            }
          : null,
      ].filter(Boolean);
  await transaction(async (db) => {
    for (let index = 0; index < keys.length; index += 1) {
      const key = keys[index];
      const invoice = data[index].invoice;
      const result = results.find((r) => String(r.invoice) === invoice);
      const success =
        result && result.status === "success" && result.consignment_id;
      if (success)
        await db.query(
          "UPDATE online_sales SET sent_to_steadfast=1,steadfast_consignment_id=?,steadfast_tracking_code=?,steadfast_tracking_link=?,steadfast_status='In Review',steadfast_last_error=NULL WHERE id=?",
          [
            result.consignment_id,
            result.tracking_code || null,
            result.tracking_link || null,
            key,
          ],
        );
      else {
        const error = String(
          result?.error ||
            response.message ||
            "Courier response did not confirm this invoice",
        );
        const duplicate = /EXISTS|duplicate/i.test(error);
        await db.query(
          `UPDATE online_sales SET steadfast_last_error=?${result && !duplicate ? ",steadfast_submitted_at=NULL" : ""} WHERE id=?`,
          [error, key],
        );
      }
    }
  });
  const orderIdByInvoice = new Map(
    data.map((order, index) => [String(order.invoice), Number(keys[index])]),
  );
  return {
    results: results.map((result) => ({
      ...result,
      order_id: orderIdByInvoice.get(String(result.invoice)) || null,
    })),
    response_status: response.status,
  };
};
exports.reconcile = async (key, raw) => {
  const optionalText = (max) =>
    z.preprocess(
      (value) => String(value ?? "").trim() || null,
      z.string().max(max).nullable(),
    );
  const b = z
    .object({
      consignment_id: id,
      tracking_code: optionalText(150),
      tracking_link: optionalText(1024).refine(
        (value) => !value || (z.string().url().safeParse(value).success && new URL(value).protocol === "https:"),
        "Tracking link must be a valid HTTPS URL",
      ),
    })
    .parse(raw);
  const response = z
    .object({
      status: z.coerce.number().int(),
      delivery_status: z.string().trim().min(1).max(100),
    })
    .passthrough()
    .parse(
      await request(`/status_by_cid/${encodeURIComponent(b.consignment_id)}`),
    );
  if (response.status !== 200)
    throw new HttpError(502, "Steadfast did not return a successful status");
  return transaction(async (db) => {
    await one(
      db,
      "SELECT * FROM online_sales WHERE id=? FOR UPDATE",
      [id.parse(key)],
    );
    const [duplicate] = await db.query(
      "SELECT id FROM online_sales WHERE steadfast_consignment_id=? AND id<>? LIMIT 1 FOR UPDATE",
      [b.consignment_id, key],
    );
    if (duplicate.length)
      throw new HttpError(409, "This consignment is already linked to another order");
    await db.query(
      "UPDATE online_sales SET sent_to_steadfast=1,steadfast_consignment_id=?,steadfast_tracking_code=?,steadfast_tracking_link=?,steadfast_status=?,steadfast_last_error=NULL WHERE id=?",
      [b.consignment_id, b.tracking_code, b.tracking_link, response.delivery_status, key],
    );
    return { linked: true, delivery_status: response.delivery_status };
  });
};
exports.refreshStatus = async (key) => {
  const saleId = id.parse(key);
  const sale = await one(
    pool,
    "SELECT id,steadfast_consignment_id FROM online_sales WHERE id=?",
    [saleId],
  );
  if (!sale.steadfast_consignment_id)
    throw new HttpError(
      409,
      "This order does not have a Steadfast consignment ID",
    );

  const response = z
    .object({
      status: z.coerce.number().int(),
      delivery_status: z.string().trim().min(1).max(100),
    })
    .passthrough()
    .parse(
      await request(
        `/status_by_cid/${encodeURIComponent(sale.steadfast_consignment_id)}`,
      ),
    );
  if (response.status !== 200)
    throw new HttpError(502, "Steadfast did not return a successful status");
  const deliveryStatus = response.delivery_status;

  await transaction(async (db) => {
    const current = await one(
      db,
      "SELECT steadfast_consignment_id FROM online_sales WHERE id=? FOR UPDATE",
      [saleId],
    );
    if (
      String(current.steadfast_consignment_id) !==
      String(sale.steadfast_consignment_id)
    )
      throw new HttpError(409, "The order consignment changed during refresh");
    await db.query(
      "UPDATE online_sales SET steadfast_status=?,steadfast_last_error=NULL WHERE id=?",
      [deliveryStatus, saleId],
    );
  });
  return response;
};
exports.refreshStatuses = async (raw) => {
  const keys = z
    .array(id)
    .min(1)
    .max(100)
    .parse(raw?.ids)
    .filter((key, index, list) => list.indexOf(key) === index);
  const results = [];
  for (const key of keys) {
    try {
      const status = await exports.refreshStatus(key);
      results.push({ id: key, delivery_status: status.delivery_status });
    } catch (error) {
      results.push({ id: key, error: error.message });
    }
  }
  return { results };
};
exports.webhook = async (raw) => {
  const acknowledge = (processed, reason) => ({
    status: "success",
    message: "Webhook received successfully",
    processed,
    ...(reason ? { reason } : {}),
  });

  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    return acknowledge(false, "Payload is not an object");

  const notificationType = String(raw.notification_type || "")
    .trim()
    .toLowerCase();
  if (notificationType !== "delivery_status")
    return acknowledge(false, "Webhook type ignored");

  const consignmentId = Number(raw.consignment_id);
  const status = String(raw.status_type || raw.status || "")
    .trim()
    .slice(0, 100);

  if (
    !Number.isSafeInteger(consignmentId) ||
    consignmentId <= 0 ||
    !status
  )
    return acknowledge(false, "Event does not contain a processable status");

  const chargeValue = raw.delivery_charge ?? raw.delivery_fee;
  const parsedCharge = chargeValue == null ? null : Number(chargeValue);
  const deliveryCharge =
    parsedCharge != null && Number.isFinite(parsedCharge) && parsedCharge >= 0
      ? Math.round(parsedCharge * 100) / 100
      : null;

  const timestamp = String(raw.updated_at || "").trim();
  const timestampMatch = timestamp.match(
    /^(\d{4}-\d{2}-\d{2})[ T](\d{2}:\d{2}:\d{2})/,
  );
  const updatedAt = timestampMatch
    ? `${timestampMatch[1]} ${timestampMatch[2]}`
    : null;

  return transaction(async (db) => {
    const [sales] = await db.query(
      `SELECT id,steadfast_consignment_id,steadfast_webhook_at
       FROM online_sales
       WHERE steadfast_consignment_id=?
       LIMIT 1 FOR UPDATE`,
      [consignmentId],
    );
    if (!sales.length)
      return acknowledge(
        false,
        "Consignment is not connected to an order",
      );

    const s = sales[0];
    if (
      s.steadfast_consignment_id &&
      String(s.steadfast_consignment_id) !== String(consignmentId)
    )
      return acknowledge(false, "Invoice and consignment do not match");

    if (
      !s.steadfast_webhook_at ||
      !updatedAt ||
      updatedAt >= s.steadfast_webhook_at
    )
      await db.query(
        "UPDATE online_sales SET steadfast_status=?,steadfast_delivery_charge=COALESCE(?,steadfast_delivery_charge),steadfast_webhook_at=COALESCE(?,NOW()) WHERE id=?",
        [status, deliveryCharge, updatedAt, s.id],
      );
    return acknowledge(true);
  });
};
exports.importPayment = async (paymentId, user) => {
  const key = z
    .string()
    .regex(/^SFC-[A-Za-z0-9-]+$/)
    .max(150)
    .parse(paymentId);
  const [stored] = await pool.query(
    "SELECT steadfast_settled_orders_details FROM steadfast_payments WHERE steadfast_payment_id=?",
    [key],
  );
  const response = stored.length
    ? typeof stored[0].steadfast_settled_orders_details === "string"
      ? JSON.parse(stored[0].steadfast_settled_orders_details)
      : stored[0].steadfast_settled_orders_details
    : await request(`/payments/${encodeURIComponent(key)}`);
  const p = z
    .object({
      payment_id: z.literal(key),
      amount,
      total: amount,
      method: z.string().max(100),
      status_label: z.string().max(255),
      created_at: z.string().nullable().optional(),
      ready_at: z.string().nullable().optional(),
      paid_at: z.string().nullable().optional(),
      consignments: z.array(
        z
          .object({
            consignment_id: id,
            invoice: z.string(),
            cod_amount: amount,
          })
          .passthrough(),
      ),
    })
    .passthrough()
    .parse(response.payment);
  if (p.total > p.amount)
    throw new HttpError(502, "Courier settlement total exceeds amount");
  return transaction(async (db) => {
    const [existing] = await db.query(
      "SELECT id FROM steadfast_payments WHERE steadfast_payment_id=? FOR UPDATE",
      [key],
    );
    const first = !existing.length;
    let settlementId = existing[0]?.id;
    if (first)
      settlementId = await insert(db, "steadfast_payments", {
        steadfast_payment_id: key,
        status: "imported",
        amount: p.amount,
        method: p.method,
        steadfast_status_label: p.status_label,
        steadfast_created_at: p.created_at || null,
        steadfast_ready_at: p.ready_at || null,
        steadfast_paid_at: p.paid_at || null,
        steadfast_settled_orders_details: JSON.stringify(response),
      });
    let [methods] = await db.query(
      "SELECT id FROM payment_methods WHERE method='STEADFAST' ORDER BY id LIMIT 1",
    );
    const methodId =
      methods[0]?.id ||
      (await insert(db, "payment_methods", { method: "STEADFAST" }));
    let matched = 0;
    let already_applied = 0;
    const unmatched = [];
    for (const c of p.consignments) {
      const [allocation] = await db.query(
        "SELECT id FROM settlement_allocations WHERE steadfast_payment_id=? AND consignment_id=?",
        [key, c.consignment_id],
      );
      if (allocation.length) {
        already_applied++;
        continue;
      }
      const [sales] = await db.query(
        "SELECT * FROM online_sales WHERE steadfast_consignment_id=? FOR UPDATE",
        [c.consignment_id],
      );
      if (!sales.length) {
        unmatched.push(c);
        continue;
      }
      const sale = sales[0];
      await insert(db, "online_sale_payments", {
        online_sale_id: sale.id,
        payment_method_id: methodId,
        amount: c.cod_amount,
        notes: `STEADFAST_PAYMENTS ${key}`,
        status: "active",
        created_by: user.id,
      });
      await insert(db, "settlement_allocations", {
        steadfast_payment_id: key,
        consignment_id: c.consignment_id,
        online_sale_id: sale.id,
        amount: c.cod_amount,
      });
      if (sale.status !== "returned") {
        const [[v]] = await db.query(
          "SELECT (SELECT COALESCE(SUM(quantity*rate),0) FROM sale_lines WHERE channel='online' AND sale_id=?) subtotal,(SELECT COALESCE(SUM(amount),0) FROM online_sale_payments WHERE online_sale_id=?) paid",
          [sale.id, sale.id],
        );
        await db.query("UPDATE online_sales SET status=? WHERE id=?", [
          v.paid >= v.subtotal - sale.final_discount + sale.delivery_charge
            ? "paid"
            : "due",
          sale.id,
        ]);
      }
      matched++;
    }
    if (first) {
      const [accounts] = await db.query(
        "SELECT id FROM expense_accounts WHERE title='steadfast_charges' ORDER BY id LIMIT 1",
      );
      const account =
        accounts[0]?.id ||
        (await insert(db, "expense_accounts", { title: "steadfast_charges" }));
      await insert(db, "expenses", {
        expense_account_id: account,
        narration: `STEADFAST_CHARGES ${key}`,
        amount: round(p.amount - p.total),
        expense_date: new Date().toLocaleDateString("en-CA", {
          timeZone: "Asia/Dhaka",
        }),
        created_by: user.id,
      });
    }
    return {
      id: settlementId,
      matched,
      already_applied,
      unmatched,
      payment: p,
    };
  });
};
exports.list = async (q) => {
  const p = pagination(q);
  const params = [];
  let where = "";
  if (q.search) {
    where = " WHERE steadfast_payment_id LIKE ?";
    params.push(`%${q.search}%`);
  }
  const [[count]] = await pool.query(
    `SELECT COUNT(*) total FROM steadfast_payments${where}`,
    params,
  );
  const [rows] = await pool.query(
    `SELECT * FROM steadfast_payments${where} ORDER BY id DESC LIMIT ? OFFSET ?`,
    [...params, p.limit, p.offset],
  );
  return pageResult(rows, count.total, p);
};
