const { pool } = require("../../config/database");
const { z, HttpError } = require("../../lib/http");
const { round } = require("../../lib/sale-math");
function range(q) {
  const today = new Date().toLocaleDateString("en-CA", {
    timeZone: "Asia/Dhaka",
  });
  const from = z
    .string()
    .date()
    .parse(q.from || `${today.slice(0, 7)}-01`);
  const to = z
    .string()
    .date()
    .parse(q.to || today);
  if (from > to) throw new HttpError(400, "Start date must be before end date");
  return { from, to };
}
async function query(sql, params) {
  const [rows] = await pool.query(sql, params);
  return rows;
}
const dateFilter = "created_at>=? AND created_at<DATE_ADD(?,INTERVAL 1 DAY)";
exports.dashboard = async (q) => {
  const { from, to } = range(q);
  const dates = [from, to];
  const [
    sales,
    cash,
    expenses,
    marketingExpenses,
    incomes,
    purchasePayments,
    trend,
    people,
    joyItems,
    steadfastStatuses,
    todayPeople,
    recent,
    stockValue,
  ] = await Promise.all([
    query(
      `SELECT COUNT(*) orders,COALESCE(SUM(v.subtotal-s.final_discount+s.delivery_charge),0) revenue,COALESCE(SUM(v.quantity),0) units,COALESCE(SUM(v.subtotal+s.delivery_charge-s.final_discount-sc.cost),0) gross_profit FROM all_sales s JOIN (SELECT channel,sale_id,SUM(quantity*rate) subtotal,SUM(quantity) quantity FROM sale_lines GROUP BY channel,sale_id) v ON BINARY v.channel=BINARY s.channel AND v.sale_id=s.id JOIN (SELECT channel,sale_id,SUM(GREATEST(quantity-returned_quantity,0)*cost_rate) cost FROM sale_components WHERE active=1 GROUP BY channel,sale_id) sc ON BINARY sc.channel=BINARY s.channel AND sc.sale_id=s.id WHERE s.status<>'returned' AND s.${dateFilter}`,
      dates,
    ),
    query(
      `SELECT COALESCE(SUM(amount),0) total FROM (SELECT amount,created_at FROM offline_sale_payments UNION ALL SELECT amount,created_at FROM online_sale_payments) p WHERE ${dateFilter}`,
      dates,
    ),
    query(
      `SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE ${dateFilter}`,
      dates,
    ),
    query(
      `SELECT COALESCE(SUM(amount_usd*conversion_rate),0) total FROM marketing_expenses WHERE ${dateFilter}`,
      dates,
    ),
    query(
      `SELECT COALESCE(SUM(amount),0) total FROM incomes WHERE ${dateFilter}`,
      dates,
    ),
    query(
      `SELECT COALESCE(SUM(amount),0) total FROM purchase_payouts WHERE ${dateFilter}`,
      dates,
    ),
    query(
      `SELECT DATE(s.created_at) date,COUNT(*) orders,SUM(l.subtotal-s.final_discount+s.delivery_charge) revenue FROM all_sales s JOIN (SELECT channel,sale_id,SUM(quantity*rate) subtotal FROM sale_lines GROUP BY channel,sale_id) l ON BINARY l.channel=BINARY s.channel AND l.sale_id=s.id WHERE s.status<>'returned' AND s.${dateFilter} GROUP BY DATE(s.created_at) ORDER BY date`,
      dates,
    ),
    query(
      `SELECT COALESCE(e.name,'Unassigned') name,COUNT(*) orders,SUM(l.units) quantity,SUM(l.subtotal-s.final_discount+s.delivery_charge) revenue FROM all_sales s LEFT JOIN employees e ON e.id=s.sales_employee_id JOIN (SELECT channel,sale_id,SUM(quantity) units,SUM(quantity*rate) subtotal FROM sale_lines GROUP BY channel,sale_id) l ON BINARY l.channel=BINARY s.channel AND l.sale_id=s.id WHERE s.status<>'returned' AND s.${dateFilter} GROUP BY s.sales_employee_id,e.name ORDER BY quantity DESC`,
      dates,
    ),
    query(
      `SELECT l.item_type,l.item_id,l.item_name name,
         COUNT(DISTINCT CONCAT(l.channel,':',l.sale_id)) quantity
       FROM sale_lines l
       JOIN all_sales s ON BINARY s.channel=BINARY l.channel AND s.id=l.sale_id
       WHERE s.status<>'returned' AND l.quantity>0 AND s.${dateFilter}
       GROUP BY l.item_type,l.item_id,l.item_name
       ORDER BY quantity DESC,name
       LIMIT 12`,
      dates,
    ),
    query(
      `SELECT COALESCE(NULLIF(TRIM(steadfast_status),''),'pending') name,COUNT(*) quantity
       FROM online_sales
       WHERE status<>'returned' AND ${dateFilter}
       GROUP BY COALESCE(NULLIF(TRIM(steadfast_status),''),'pending')
       ORDER BY quantity DESC,name`,
      dates,
    ),
    query(
      "SELECT COALESCE(e.name,'Unassigned') name,COUNT(*) orders FROM all_sales s LEFT JOIN employees e ON e.id=s.sales_employee_id WHERE s.status<>'returned' AND DATE(s.created_at)=CURDATE() GROUP BY s.sales_employee_id,e.name ORDER BY orders DESC",
    ),
    query(
      `SELECT s.channel,s.id,s.status,s.created_at,c.cus_name,COALESCE(e.name,'Unassigned') sales_person_name,l.subtotal-s.final_discount+s.delivery_charge payable FROM all_sales s JOIN customers c ON c.id=s.customer_id LEFT JOIN employees e ON e.id=s.sales_employee_id JOIN (SELECT channel,sale_id,SUM(quantity*rate) subtotal FROM sale_lines GROUP BY channel,sale_id) l ON BINARY l.channel=BINARY s.channel AND l.sale_id=s.id WHERE s.${dateFilter} ORDER BY s.created_at DESC,s.id DESC LIMIT 6`,
      dates,
    ),
    query(
      "SELECT COALESCE(SUM(GREATEST(ps.stock,0)*p.purchase_price),0) total FROM product_stock ps JOIN products p ON p.id=ps.product_id",
    ),
  ]);
  const salePayments = cash[0].total;
  const cashIn = round(salePayments + incomes[0].total);
  const cashOut = round(
    expenses[0].total +
      marketingExpenses[0].total +
      purchasePayments[0].total,
  );
  let dailyTrend = trend;
  const dayCount =
    Math.round((Date.parse(to) - Date.parse(from)) / 86400000) + 1;
  if (trend.length && dayCount <= 730) {
    const byDate = new Map(trend.map((row) => [row.date, row]));
    dailyTrend = Array.from({ length: dayCount }, (_, index) => {
      const date = new Date(Date.parse(`${from}T00:00:00Z`) + index * 86400000)
        .toISOString()
        .slice(0, 10);
      return byDate.get(date) || { date, orders: 0, revenue: 0 };
    });
  }
  return {
    from,
    to,
    ...sales[0],
    sale_payments: salePayments,
    other_income: incomes[0].total,
    expenses: expenses[0].total,
    marketing_expenses: marketingExpenses[0].total,
    purchase_payments: purchasePayments[0].total,
    cash_in: cashIn,
    cash_out: cashOut,
    profit: round(cashIn - cashOut),
    net_operating_profit: round(
      sales[0].gross_profit +
        incomes[0].total -
        expenses[0].total -
        marketingExpenses[0].total,
    ),
    current_stock_value: stockValue[0].total,
    trend: dailyTrend,
    people,
    joy_items: joyItems.map((row) => ({
      ...row,
      quantity: Number(row.quantity),
    })),
    steadfast_statuses: steadfastStatuses.map((row) => ({
      ...row,
      quantity: Number(row.quantity),
    })),
    todayPeople,
    recent,
  };
};
const reports = {
  "daily-salesperson": { period: "DATE(s.created_at)", person: true },
  "monthly-salesperson": {
    period: "DATE_FORMAT(s.created_at,'%Y-%m')",
    person: true,
  },
  "daily-product": { period: "DATE(s.created_at)", item: true },
  "salesperson-count": { period: "'Selected period'", person: true },
  "monthly-product-salesperson": {
    period: "DATE_FORMAT(s.created_at,'%Y-%m')",
    person: true,
    item: true,
  },
  "monthly-product": {
    period: "DATE_FORMAT(s.created_at,'%Y-%m')",
    item: true,
  },
};

const optionalReportId = (value) =>
  value == null || value === ""
    ? null
    : z.coerce.number().int().positive().parse(value);

async function salesExplorer(q) {
  const { from, to } = range(q);
  const employeeId = optionalReportId(q.sales_employee_id);
  const categoryId = optionalReportId(q.category_id);
  const paymentMethodId = optionalReportId(q.payment_method_id);
  const channelFilter = q.channel
    ? z.enum(["offline", "online"]).parse(q.channel)
    : null;
  const statusFilter = q.status
    ? z.enum(["paid", "due"]).parse(q.status)
    : null;
  const customerSearch = String(q.customer || "").trim().slice(0, 100);
  let itemType = null;
  let itemId = null;
  if (q.item) {
    const match = /^(product|combo):(\d+)$/.exec(String(q.item));
    if (!match) throw new HttpError(400, "Invalid product filter");
    itemType = match[1];
    itemId = z.coerce.number().int().positive().parse(match[2]);
  }

  const conditions = [
    "s.status<>'returned'",
    `s.${dateFilter}`,
  ];
  const params = [from, to];
  if (employeeId) {
    conditions.push("s.sales_employee_id=?");
    params.push(employeeId);
  }
  if (channelFilter) {
    conditions.push("s.channel=?");
    params.push(channelFilter);
  }
  if (statusFilter) {
    conditions.push("s.status=?");
    params.push(statusFilter);
  }
  if (itemType) {
    conditions.push("l.item_type=?", "l.item_id=?");
    params.push(itemType, itemId);
  }
  if (categoryId) {
    conditions.push(
      "((l.item_type='combo' AND EXISTS(SELECT 1 FROM product_combos fpc WHERE fpc.id=l.item_id AND fpc.category_id=?)) OR (l.item_type='product' AND EXISTS(SELECT 1 FROM sale_line_components fsc JOIN products fp ON fp.id=fsc.product_id WHERE BINARY fsc.channel=BINARY l.channel AND fsc.sale_id=l.sale_id AND BINARY fsc.item_type=BINARY l.item_type AND fsc.sale_line_id=l.line_id AND fp.category_id=?)) OR (l.item_type='combo' AND NOT EXISTS(SELECT 1 FROM product_combos fpc WHERE fpc.id=l.item_id AND fpc.category_id IS NOT NULL) AND EXISTS(SELECT 1 FROM sale_line_components fsc JOIN products fp ON fp.id=fsc.product_id WHERE BINARY fsc.channel=BINARY l.channel AND fsc.sale_id=l.sale_id AND BINARY fsc.item_type=BINARY l.item_type AND fsc.sale_line_id=l.line_id AND fp.category_id=?)))",
    );
    params.push(categoryId, categoryId, categoryId);
  }
  if (paymentMethodId) {
    conditions.push(
      "EXISTS(SELECT 1 FROM offline_sale_payments ofp WHERE s.channel='offline' AND ofp.offline_sale_id=s.id AND ofp.payment_method_id=? AND ofp.status='active' UNION ALL SELECT 1 FROM online_sale_payments onp WHERE s.channel='online' AND onp.online_sale_id=s.id AND onp.payment_method_id=? AND onp.status='active')",
    );
    params.push(paymentMethodId, paymentMethodId);
  }
  if (customerSearch) {
    conditions.push("(cu.cus_name LIKE ? OR cu.cus_phone LIKE ?)");
    params.push(`%${customerSearch}%`, `%${customerSearch}%`);
  }

  const where = conditions.join(" AND ");
  const lineCost = `LEFT JOIN (
    SELECT slc.channel,slc.sale_id,slc.item_type,slc.sale_line_id,
      SUM(slc.component_quantity*sc.cost_rate) unit_cost
    FROM sale_line_components slc
    JOIN sale_components sc ON BINARY sc.channel=BINARY slc.channel AND sc.sale_id=slc.sale_id AND sc.product_id=slc.product_id
    GROUP BY slc.channel,slc.sale_id,slc.item_type,slc.sale_line_id
  ) lc ON BINARY lc.channel=BINARY l.channel AND lc.sale_id=l.sale_id AND BINARY lc.item_type=BINARY l.item_type AND lc.sale_line_id=l.line_id`;
  const base = `SELECT s.channel,s.id sale_id,s.created_at,s.status,s.delivery_charge,
    s.sales_employee_id,COALESCE(e.name,'Unassigned') sales_person,
    cu.id customer_id,cu.cus_name customer_name,cu.cus_phone customer_phone,
    l.item_type,l.item_id,l.item_name,l.quantity,l.rate,
    l.quantity*l.rate gross_sales,
    COALESCE(s.final_discount/NULLIF(st.subtotal,0),0)*l.quantity*l.rate allocated_discount,
    l.quantity*l.rate-COALESCE(s.final_discount/NULLIF(st.subtotal,0),0)*l.quantity*l.rate net_sales,
    l.quantity*COALESCE(lc.unit_cost,0) sold_cost
    FROM all_sales s
    JOIN customers cu ON cu.id=s.customer_id
    LEFT JOIN employees e ON e.id=s.sales_employee_id
    JOIN sale_lines l ON BINARY l.channel=BINARY s.channel AND l.sale_id=s.id
    JOIN (SELECT channel,sale_id,SUM(quantity*rate) subtotal FROM sale_lines GROUP BY channel,sale_id) st ON BINARY st.channel=BINARY s.channel AND st.sale_id=s.id
    ${lineCost}
    WHERE ${where}`;

  const baseParams = () => [...params];
  const [lineSummary, orderSummary, daily, people, products, channels, customers, orders, categories, optionRows] =
    await Promise.all([
      query(
        `SELECT COALESCE(SUM(quantity),0) quantity,COALESCE(SUM(gross_sales),0) gross_sales,COALESCE(SUM(allocated_discount),0) allocated_discount,COALESCE(SUM(net_sales),0) net_product_sales,COALESCE(SUM(sold_cost),0) sold_cost FROM (${base}) filtered_lines`,
        baseParams(),
      ),
      query(
        `SELECT COUNT(*) sale_count,COALESCE(SUM(delivery_charge),0) delivery_charge FROM (SELECT channel,sale_id,MAX(delivery_charge) delivery_charge FROM (${base}) filtered_lines GROUP BY channel,sale_id) filtered_orders`,
        baseParams(),
      ),
      query(
        `SELECT DATE(created_at) period,COUNT(DISTINCT CONCAT(channel,':',sale_id)) sale_count,SUM(quantity) quantity,SUM(net_sales) net_sales,SUM(sold_cost) sold_cost FROM (${base}) filtered_lines GROUP BY DATE(created_at) ORDER BY period`,
        baseParams(),
      ),
      query(
        `SELECT sales_person,COUNT(DISTINCT CONCAT(channel,':',sale_id)) sale_count,SUM(quantity) quantity,SUM(net_sales) net_sales,SUM(sold_cost) sold_cost FROM (${base}) filtered_lines GROUP BY sales_employee_id,sales_person ORDER BY net_sales DESC`,
        baseParams(),
      ),
      query(
        `SELECT item_type,item_id,item_name,COUNT(DISTINCT CONCAT(channel,':',sale_id)) sale_count,SUM(quantity) quantity,SUM(gross_sales) gross_sales,SUM(allocated_discount) allocated_discount,SUM(net_sales) net_sales,SUM(sold_cost) sold_cost FROM (${base}) filtered_lines GROUP BY item_type,item_id,item_name ORDER BY net_sales DESC`,
        baseParams(),
      ),
      query(
        `SELECT channel,COUNT(DISTINCT CONCAT(channel,':',sale_id)) sale_count,SUM(quantity) quantity,SUM(net_sales) net_sales,SUM(sold_cost) sold_cost FROM (${base}) filtered_lines GROUP BY channel ORDER BY net_sales DESC`,
        baseParams(),
      ),
      query(
        `SELECT customer_id,customer_name,customer_phone,COUNT(DISTINCT CONCAT(channel,':',sale_id)) sale_count,SUM(quantity) quantity,SUM(net_sales) net_sales FROM (${base}) filtered_lines GROUP BY customer_id,customer_name,customer_phone ORDER BY net_sales DESC LIMIT 100`,
        baseParams(),
      ),
      query(
        `SELECT channel,sale_id,MAX(created_at) created_at,MAX(status) status,MAX(customer_name) customer_name,MAX(customer_phone) customer_phone,MAX(sales_person) sales_person,SUM(quantity) quantity,SUM(net_sales) net_product_sales,MAX(delivery_charge) delivery_charge,SUM(net_sales)+MAX(delivery_charge) payable,SUM(sold_cost) sold_cost FROM (${base}) filtered_lines GROUP BY channel,sale_id ORDER BY created_at DESC,sale_id DESC LIMIT 500`,
        baseParams(),
      ),
      query(
        `SELECT category,row_kind,sale_count,component_quantity,sold_cost FROM (
           SELECT COALESCE(c.category_name,'Uncategorized') category,'category' row_kind,
             COUNT(DISTINCT CONCAT(s.channel,':',s.id)) sale_count,
             SUM(l.quantity*ac.component_quantity) component_quantity,
             SUM(l.quantity*ac.unit_cost) sold_cost
           FROM all_sales s JOIN customers cu ON cu.id=s.customer_id LEFT JOIN employees e ON e.id=s.sales_employee_id
           JOIN sale_lines l ON BINARY l.channel=BINARY s.channel AND l.sale_id=s.id
           JOIN (
             SELECT slc.channel,slc.sale_id,slc.item_type,slc.sale_line_id,
               MAX(p.category_id) product_category_id,
               SUM(slc.component_quantity) component_quantity,
               SUM(slc.component_quantity*COALESCE(sc.cost_rate,0)) unit_cost
             FROM sale_line_components slc
             JOIN products p ON p.id=slc.product_id
             LEFT JOIN sale_components sc ON BINARY sc.channel=BINARY slc.channel AND sc.sale_id=slc.sale_id AND sc.product_id=slc.product_id
             GROUP BY slc.channel,slc.sale_id,slc.item_type,slc.sale_line_id
           ) ac ON BINARY ac.channel=BINARY l.channel AND ac.sale_id=l.sale_id AND BINARY ac.item_type=BINARY l.item_type AND ac.sale_line_id=l.line_id
           LEFT JOIN product_combos pc ON BINARY l.item_type=BINARY 'combo' AND pc.id=l.item_id
           LEFT JOIN categories c ON c.id=CASE WHEN l.item_type='combo' THEN pc.category_id ELSE ac.product_category_id END
           WHERE ${where} AND (l.item_type='product' OR (l.item_type='combo' AND pc.category_id IS NOT NULL))
           GROUP BY CASE WHEN l.item_type='combo' THEN pc.category_id ELSE ac.product_category_id END,c.category_name

           UNION ALL

           SELECT CONCAT('COMBO(',ac.category_names,')') category,
             'combo' row_kind,COUNT(DISTINCT CONCAT(s.channel,':',s.id)) sale_count,
             SUM(l.quantity*ac.component_quantity) component_quantity,
             SUM(l.quantity*ac.unit_cost) sold_cost
           FROM all_sales s JOIN customers cu ON cu.id=s.customer_id LEFT JOIN employees e ON e.id=s.sales_employee_id
           JOIN sale_lines l ON BINARY l.channel=BINARY s.channel AND l.sale_id=s.id
           JOIN (
             SELECT cc.channel,cc.sale_id,cc.item_type,cc.sale_line_id,
               GROUP_CONCAT(DISTINCT COALESCE(c.category_name,'Uncategorized') ORDER BY COALESCE(c.category_name,'Uncategorized') SEPARATOR ', ') category_names,
               SUM(cc.component_quantity) component_quantity,SUM(cc.unit_cost) unit_cost
             FROM (
               SELECT slc.channel,slc.sale_id,slc.item_type,slc.sale_line_id,p.category_id,
                 SUM(slc.component_quantity) component_quantity,
                 SUM(slc.component_quantity*COALESCE(sc.cost_rate,0)) unit_cost
               FROM sale_line_components slc
               JOIN products p ON p.id=slc.product_id
               LEFT JOIN sale_components sc ON BINARY sc.channel=BINARY slc.channel AND sc.sale_id=slc.sale_id AND sc.product_id=slc.product_id
               GROUP BY slc.channel,slc.sale_id,slc.item_type,slc.sale_line_id,p.category_id
             ) cc
             LEFT JOIN categories c ON c.id=cc.category_id
             GROUP BY cc.channel,cc.sale_id,cc.item_type,cc.sale_line_id
           ) ac ON BINARY ac.channel=BINARY l.channel AND ac.sale_id=l.sale_id AND BINARY ac.item_type=BINARY l.item_type AND ac.sale_line_id=l.line_id
           LEFT JOIN product_combos pc ON pc.id=l.item_id
           WHERE ${where} AND l.item_type='combo' AND pc.category_id IS NULL
           GROUP BY ac.category_names
         ) category_rows ORDER BY component_quantity DESC,category`,
        [...params, ...params],
      ),
      Promise.all([
        query("SELECT id,name FROM employees ORDER BY name"),
        query("SELECT id,category_name name FROM categories ORDER BY category_name"),
        query("SELECT id,method name FROM payment_methods ORDER BY method"),
        query("SELECT CONCAT('product:',id) value,product_name name,barcode,'product' item_type FROM products WHERE status='active' UNION ALL SELECT CONCAT('combo:',id),combo_name,barcode,'combo' FROM product_combos ORDER BY name"),
      ]),
    ]);

  const summary = {
    ...lineSummary[0],
    ...orderSummary[0],
  };
  summary.gross_profit = round(
    Number(summary.net_product_sales) +
      Number(summary.delivery_charge) -
      Number(summary.sold_cost),
  );
  return {
    from,
    to,
    summary,
    daily,
    salespeople: people,
    categories,
    products,
    channels,
    customers,
    orders,
    options: {
      employees: optionRows[0],
      categories: optionRows[1],
      payment_methods: optionRows[2],
      items: optionRows[3],
    },
  };
}

const listFilter = (value, parser, max = 250) => {
  if (value == null || value === "") return [];
  const values = [...new Set(String(value).split(",").map((part) => part.trim()).filter(Boolean))];
  if (values.length > max) throw new HttpError(400, "Too many filter values");
  return values.map(parser);
};

async function marketingReport(q) {
  const { from, to } = range(q);
  const employeeIds = listFilter(q.sales_employee_ids, (value) =>
    z.coerce.number().int().positive().parse(value),
  );
  const barcodes = listFilter(q.barcodes, (value) =>
    z.string().trim().min(1).max(100).parse(value),
  );
  const statuses = listFilter(q.steadfast_statuses, (value) =>
    z.string().trim().min(1).max(100).parse(value),
  );
  const saleConditions = [
    "s.status<>'returned'",
    `s.${dateFilter}`,
  ];
  const saleParams = [from, to];
  const expenseConditions = [`m.${dateFilter}`];
  const expenseParams = [from, to];
  if (employeeIds.length) {
    saleConditions.push("s.sales_employee_id IN (?)");
    saleParams.push(employeeIds);
    expenseConditions.push("m.sales_person_id IN (?)");
    expenseParams.push(employeeIds);
  }
  if (barcodes.length) {
    saleConditions.push("p.barcode IN (?)");
    saleParams.push(barcodes);
    expenseConditions.push("m.barcode IN (?)");
    expenseParams.push(barcodes);
  }
  if (statuses.length) {
    saleConditions.push(
      "COALESCE(NULLIF(TRIM(s.steadfast_status),''),'pending') IN (?)",
    );
    saleParams.push(statuses);
  }
  const soldProducts = `(SELECT DISTINCT sale_id,product_id FROM sale_line_components WHERE channel='online')`;
  const saleFrom = `FROM online_sales s
    JOIN ${soldProducts} sp ON sp.sale_id=s.id
    JOIN products p ON p.id=sp.product_id
    LEFT JOIN employees e ON e.id=s.sales_employee_id
    WHERE ${saleConditions.join(" AND ")}`;
  const [orderRows, expenseRows, totalStatusRows, productOptions, employeeOptions, statusOptions] =
    await Promise.all([
      query(
        `SELECT p.barcode,p.product_name,s.sales_employee_id,
          COALESCE(e.name,'Unassigned') sales_person,
          COALESCE(NULLIF(TRIM(s.steadfast_status),''),'pending') steadfast_status,
          COUNT(DISTINCT s.id) order_count
         ${saleFrom}
         GROUP BY p.barcode,p.product_name,s.sales_employee_id,e.name,steadfast_status`,
        [...saleParams],
      ),
      query(
        `SELECT m.barcode,p.product_name,m.sales_person_id sales_employee_id,e.name sales_person,
          SUM(m.amount_usd) total_ad_expense_usd,
          SUM(m.amount_usd*m.conversion_rate) total_ad_expense_bdt
         FROM marketing_expenses m
         JOIN products p ON p.barcode=m.barcode
         JOIN employees e ON e.id=m.sales_person_id
         WHERE ${expenseConditions.join(" AND ")}
         GROUP BY m.barcode,p.product_name,m.sales_person_id,e.name`,
        [...expenseParams],
      ),
      query(
        `SELECT COALESCE(NULLIF(TRIM(s.steadfast_status),''),'pending') steadfast_status,
          COUNT(DISTINCT s.id) order_count ${saleFrom}
         GROUP BY steadfast_status`,
        [...saleParams],
      ),
      query(
        "SELECT barcode,product_name FROM products WHERE barcode IS NOT NULL AND barcode<>'' ORDER BY product_name",
      ),
      query("SELECT id,name FROM employees ORDER BY name"),
      query(
        "SELECT DISTINCT COALESCE(NULLIF(TRIM(steadfast_status),''),'pending') status_value FROM online_sales ORDER BY 1",
      ),
    ]);

  const detailMap = new Map();
  const detailKey = (barcode, employeeId) =>
    `${barcode}\u0000${employeeId == null ? "unassigned" : employeeId}`;
  const ensureDetail = (row) => {
    const key = detailKey(row.barcode, row.sales_employee_id);
    if (!detailMap.has(key))
      detailMap.set(key, {
        barcode: row.barcode,
        product_name: row.product_name,
        sales_employee_id: row.sales_employee_id,
        sales_person: row.sales_person || "Unassigned",
        order_count: 0,
        statusCounts: {},
        total_ad_expense_usd: 0,
        total_ad_expense_bdt: 0,
      });
    return detailMap.get(key);
  };
  for (const row of orderRows) {
    const detail = ensureDetail(row);
    const count = Number(row.order_count);
    detail.order_count += count;
    detail.statusCounts[row.steadfast_status] =
      (detail.statusCounts[row.steadfast_status] || 0) + count;
  }
  for (const row of expenseRows) {
    const detail = ensureDetail(row);
    detail.total_ad_expense_usd = Number(row.total_ad_expense_usd);
    detail.total_ad_expense_bdt = Number(row.total_ad_expense_bdt);
  }
  const statusText = (counts) =>
    Object.entries(counts)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([status, count]) => `${status}: ${count}`)
      .join(", ") || "No matching orders";
  const publicRow = (row) => ({
    barcode: row.barcode,
    product_name: row.product_name,
    ...(row.sales_person !== undefined ? { sales_person: row.sales_person } : {}),
    order_count: row.order_count,
    status_breakdown: statusText(row.statusCounts),
    total_ad_expense_usd: round(row.total_ad_expense_usd),
    average_conversion_rate: row.total_ad_expense_usd
      ? round(row.total_ad_expense_bdt / row.total_ad_expense_usd)
      : 0,
    total_ad_expense_bdt: round(row.total_ad_expense_bdt),
    ad_expense_per_order_bdt: row.order_count
      ? round(row.total_ad_expense_bdt / row.order_count)
      : 0,
  });
  const details = [...detailMap.values()]
    .map(publicRow)
    .sort((left, right) =>
      left.product_name.localeCompare(right.product_name) ||
      left.sales_person.localeCompare(right.sales_person),
    );
  const productMap = new Map();
  for (const detail of detailMap.values()) {
    if (!productMap.has(detail.barcode))
      productMap.set(detail.barcode, {
        barcode: detail.barcode,
        product_name: detail.product_name,
        order_count: 0,
        statusCounts: {},
        total_ad_expense_usd: 0,
        total_ad_expense_bdt: 0,
      });
    const product = productMap.get(detail.barcode);
    product.order_count += detail.order_count;
    product.total_ad_expense_usd += detail.total_ad_expense_usd;
    product.total_ad_expense_bdt += detail.total_ad_expense_bdt;
    for (const [status, count] of Object.entries(detail.statusCounts))
      product.statusCounts[status] = (product.statusCounts[status] || 0) + count;
  }
  const products = [...productMap.values()]
    .map(publicRow)
    .sort((left, right) => right.total_ad_expense_bdt - left.total_ad_expense_bdt);
  const totalOrders = totalStatusRows.reduce(
    (total, row) => total + Number(row.order_count),
    0,
  );
  const totalUsd = expenseRows.reduce(
    (total, row) => total + Number(row.total_ad_expense_usd),
    0,
  );
  const totalBdt = expenseRows.reduce(
    (total, row) => total + Number(row.total_ad_expense_bdt),
    0,
  );
  return {
    from,
    to,
    summary: {
      total_order_count: totalOrders,
      status_breakdown: statusText(
        Object.fromEntries(
          totalStatusRows.map((row) => [row.steadfast_status, Number(row.order_count)]),
        ),
      ),
      selected_product_count: productMap.size,
      total_ad_expense_usd: round(totalUsd),
      total_ad_expense_bdt: round(totalBdt),
      ad_expense_per_order_bdt: totalOrders ? round(totalBdt / totalOrders) : 0,
    },
    products,
    details,
    options: {
      products: productOptions,
      employees: employeeOptions,
      steadfast_statuses: statusOptions.map((row) => row.status_value),
    },
  };
}

exports.report = async (type, q) => {
  if (type === "sales-explorer") return salesExplorer(q);
  if (type === "marketing") return marketingReport(q);
  if (type === "revenue-expense") {
    const { from, to } = range(q);
    const [salesRows, incomeRows, expenseRows, marketingRows] = await Promise.all([
      query(
        `SELECT DATE(s.created_at) period,
          COALESCE(SUM(st.subtotal-s.final_discount+s.delivery_charge),0) sales_revenue,
          COALESCE(SUM(sc.sold_purchase_cost),0) sold_purchase_cost
         FROM all_sales s
         JOIN (SELECT channel,sale_id,SUM(quantity*rate) subtotal FROM sale_lines GROUP BY channel,sale_id) st
           ON BINARY st.channel=BINARY s.channel AND st.sale_id=s.id
         LEFT JOIN (
           SELECT channel,sale_id,SUM(GREATEST(quantity-returned_quantity,0)*cost_rate) sold_purchase_cost
           FROM sale_components WHERE active=1 GROUP BY channel,sale_id
         ) sc ON BINARY sc.channel=BINARY s.channel AND sc.sale_id=s.id
         WHERE s.status<>'returned' AND s.${dateFilter}
         GROUP BY DATE(s.created_at) ORDER BY period`,
        [from, to],
      ),
      query(
        "SELECT income_date period,COALESCE(SUM(amount),0) other_income FROM incomes WHERE income_date>=? AND income_date<=? GROUP BY income_date ORDER BY income_date",
        [from, to],
      ),
      query(
        "SELECT expense_date period,COALESCE(SUM(amount),0) operating_expenses FROM expenses WHERE expense_date>=? AND expense_date<=? GROUP BY expense_date ORDER BY expense_date",
        [from, to],
      ),
      query(
        "SELECT DATE(created_at) period,COALESCE(SUM(amount_usd*conversion_rate),0) marketing_expenses FROM marketing_expenses WHERE created_at>=? AND created_at<DATE_ADD(?,INTERVAL 1 DAY) GROUP BY DATE(created_at) ORDER BY period",
        [from, to],
      ),
    ]);
    const keyOf = (value) =>
      value instanceof Date
        ? value.toISOString().slice(0, 10)
        : String(value).slice(0, 10);
    const byDate = new Map();
    const ensure = (period) => {
      const key = keyOf(period);
      if (!byDate.has(key))
        byDate.set(key, {
          period: key,
          sales_revenue: 0,
          other_income: 0,
          total_revenue: 0,
          operating_expenses: 0,
          marketing_expenses: 0,
          sold_purchase_cost: 0,
          total_cost: 0,
          net_profit: 0,
          net_margin_percent: 0,
        });
      return byDate.get(key);
    };
    for (const row of salesRows)
      Object.assign(ensure(row.period), {
        sales_revenue: Number(row.sales_revenue),
        sold_purchase_cost: Number(row.sold_purchase_cost),
      });
    for (const row of incomeRows)
      ensure(row.period).other_income = Number(row.other_income);
    for (const row of expenseRows)
      ensure(row.period).operating_expenses = Number(row.operating_expenses);
    for (const row of marketingRows)
      ensure(row.period).marketing_expenses = Number(row.marketing_expenses);

    const dayCount = Math.round((Date.parse(to) - Date.parse(from)) / 86400000) + 1;
    if (dayCount <= 730) {
      for (let index = 0; index < dayCount; index += 1)
        ensure(
          new Date(Date.parse(`${from}T00:00:00Z`) + index * 86400000)
            .toISOString()
            .slice(0, 10),
        );
    }
    const rows = [...byDate.values()]
      .sort((a, b) => a.period.localeCompare(b.period))
      .map((row) => {
        row.total_revenue = round(row.sales_revenue + row.other_income);
        row.total_cost = round(
          row.operating_expenses +
            row.marketing_expenses +
            row.sold_purchase_cost,
        );
        row.net_profit = round(row.total_revenue - row.total_cost);
        row.net_margin_percent = row.total_revenue
          ? round((row.net_profit / row.total_revenue) * 100)
          : 0;
        return row;
      });
    return { from, to, rows };
  }
  const config = reports[type];
  if (!config) throw new HttpError(404, "Unknown report");
  const { from, to } = range(q);
  const select = [`${config.period} period`];
  const group = ["period"];
  if (config.person) {
    select.push("COALESCE(e.name,'Unassigned') sales_person");
    group.push("s.sales_employee_id", "e.name");
  }
  if (config.item) {
    select.push("l.item_type", "l.item_id", "l.item_name");
    group.push("l.item_type", "l.item_id", "l.item_name");
  }
  const rows = await query(
    `SELECT ${select.join(",")},COUNT(DISTINCT CONCAT(s.channel,':',s.id)) sale_count,SUM(l.quantity) quantity,SUM(l.quantity*l.rate) gross_sales,SUM(COALESCE(s.final_discount/NULLIF(st.subtotal,0),0)*l.quantity*l.rate) allocated_discount,SUM(l.quantity*l.rate-COALESCE(s.final_discount/NULLIF(st.subtotal,0),0)*l.quantity*l.rate) net_sales FROM all_sales s JOIN sale_lines l ON BINARY l.channel=BINARY s.channel AND l.sale_id=s.id JOIN (SELECT channel,sale_id,SUM(quantity*rate) subtotal FROM sale_lines GROUP BY channel,sale_id) st ON BINARY st.channel=BINARY s.channel AND st.sale_id=s.id LEFT JOIN employees e ON e.id=s.sales_employee_id WHERE s.status<>'returned' AND s.${dateFilter} GROUP BY ${group.join(",")} ORDER BY period DESC,net_sales DESC`,
    [from, to],
  );
  return { from, to, rows };
};
